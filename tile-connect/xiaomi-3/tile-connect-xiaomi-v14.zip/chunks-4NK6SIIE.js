import{r as a,s as b}from"./chunks-KNQDPGN5.js";b();export{a as default};
