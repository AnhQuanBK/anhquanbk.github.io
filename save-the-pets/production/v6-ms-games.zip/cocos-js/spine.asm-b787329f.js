System.register([],(function(t){"use strict";return{execute:function(){t("default",(function(){}))}}}));
